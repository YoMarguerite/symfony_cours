<?php

/* vol/reservation.html.twig */
class __TwigTemplate_afb71b6a9ea031308a4355314b854cec087a1cfa460500de3af6d3ffb9c31367 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "vol/reservation.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/reservation.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/reservation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "  <div class=\"row\">
    <div class=\"col s12\">
      <div class=\"card\">
        <div class=\"card-content\">
          <span class=\"card-title center\">";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 8, $this->source); })()), "Trajet", []), "Depart", []), "Nom", []), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 8, $this->source); })()), "Trajet", []), "Arrivee", []), "Nom", []), "html", null, true);
        echo "</span>
          <p>Départ à ";
        // line 9
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 9, $this->source); })()), "Depart", []), "Y-m-d H:i:s"), "html", null, true);
        echo " et Arrivée à ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 9, $this->source); })()), "Arrivee", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
          <p>";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["message"]) || array_key_exists("message", $context) ? $context["message"] : (function () { throw new Twig_Error_Runtime('Variable "message" does not exist.', 10, $this->source); })()), "html", null, true);
        echo "</p>
        </div>
        <div class=\"card-action\">
          <a class=\"btn waves-effect waves-light red lighten-1\" href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">Accueil</a>
          <a class=\"btn waves-effect waves-light red lighten-1\" href=\"";
        // line 14
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("our-flight");
        echo "\">Vos Vols</a>
        </div>
      </div>
    </div>
  </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "vol/reservation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 14,  77 => 13,  71 => 10,  65 => 9,  59 => 8,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
  <div class=\"row\">
    <div class=\"col s12\">
      <div class=\"card\">
        <div class=\"card-content\">
          <span class=\"card-title center\">{{vol.Trajet.Depart.Nom}} - {{vol.Trajet.Arrivee.Nom}}</span>
          <p>Départ à {{ vol.Depart|date('Y-m-d H:i:s') }} et Arrivée à {{ vol.Arrivee|date('Y-m-d H:i:s') }}</p>
          <p>{{message}}</p>
        </div>
        <div class=\"card-action\">
          <a class=\"btn waves-effect waves-light red lighten-1\" href=\"{{path(\"home\")}}\">Accueil</a>
          <a class=\"btn waves-effect waves-light red lighten-1\" href=\"{{path(\"our-flight\")}}\">Vos Vols</a>
        </div>
      </div>
    </div>
  </div>
{% endblock %}
", "vol/reservation.html.twig", "C:\\symfony\\AirAtlantique\\templates\\vol\\reservation.html.twig");
    }
}
