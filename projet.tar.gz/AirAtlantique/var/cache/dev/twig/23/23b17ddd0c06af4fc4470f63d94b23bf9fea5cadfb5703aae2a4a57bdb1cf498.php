<?php

/* /vol/_card_vol.html.twig */
class __TwigTemplate_c72d36d91f9b5165495d88ff638f7a437610df8ae0b9ba0b491688df28eefd6a extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/vol/_card_vol.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/vol/_card_vol.html.twig"));

        // line 1
        echo "<tr>
    <td>
        <p>Départ : ";
        // line 3
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 3, $this->source); })()), "Depart", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
        <p>Arrivée : ";
        // line 4
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 4, $this->source); })()), "Arrivee", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
    </td>
    <td>
        <p>Avion : ";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 7, $this->source); })()), "Avion", []), "Modele", []), "html", null, true);
        echo "</p>
        <p>Places Restantes : ";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 8, $this->source); })()), "getPlacesRestantes", [], "method"), "html", null, true);
        echo "</p>
    </td>
    <td>
        <p>Durée : ";
        // line 11
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 11, $this->source); })()), "Trajet", []), "Duree", []), "H:i:s"), "html", null, true);
        echo "</p> 
        <p>Distance : ";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 12, $this->source); })()), "Trajet", []), "Distance", []), "html", null, true);
        echo " KM</p>
    </td>

    ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new Twig_Error_Runtime('Variable "classes" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["classe"]) {
            // line 16
            echo "        ";
            $context["condition"] = true;
            // line 17
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 17, $this->source); })()), "tarifVols", []));
            foreach ($context['_seq'] as $context["_key"] => $context["tarifvol"]) {
                if ((isset($context["condition"]) || array_key_exists("condition", $context) ? $context["condition"] : (function () { throw new Twig_Error_Runtime('Variable "condition" does not exist.', 17, $this->source); })())) {
                    // line 18
                    echo "            ";
                    if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["tarifvol"], "Tarif", []), "Classe", []), "id", []) == twig_get_attribute($this->env, $this->source, $context["classe"], "id", []))) {
                        // line 19
                        echo "                <td>
                    <table>
                        ";
                        // line 21
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["vol"]) || array_key_exists("vol", $context) ? $context["vol"] : (function () { throw new Twig_Error_Runtime('Variable "vol" does not exist.', 21, $this->source); })()), "tarifVols", []));
                        foreach ($context['_seq'] as $context["_key"] => $context["tarifvol"]) {
                            // line 22
                            echo "                            ";
                            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["tarifvol"], "Tarif", []), "Classe", []), "id", []) == twig_get_attribute($this->env, $this->source, $context["classe"], "id", []))) {
                                // line 23
                                echo "                                <tr>
                                    <td>
                                        <input style=\"position:relative;opacity:1;pointer-events:auto\" name=\"choix\" value=\"";
                                // line 25
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tarifvol"], "id", []), "html", null, true);
                                echo "\" type=\"radio\" id=\"";
                                echo twig_escape_filter($this->env, (isset($context["compteur"]) || array_key_exists("compteur", $context) ? $context["compteur"] : (function () { throw new Twig_Error_Runtime('Variable "compteur" does not exist.', 25, $this->source); })()), "html", null, true);
                                echo "\"/>
                                        <label for=\"";
                                // line 26
                                echo twig_escape_filter($this->env, (isset($context["compteur"]) || array_key_exists("compteur", $context) ? $context["compteur"] : (function () { throw new Twig_Error_Runtime('Variable "compteur" does not exist.', 26, $this->source); })()), "html", null, true);
                                echo "\">";
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["tarifvol"], "Tarif", []), "Tarif", []), "html", null, true);
                                echo " : ";
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tarifvol"], "Prix", []), "html", null, true);
                                echo " €</label>
                                    </td>
                                </tr>
                            ";
                            }
                            // line 30
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tarifvol'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 31
                        echo "                    </table>             
                </td>
                ";
                        // line 33
                        $context["compteur"] = ((isset($context["compteur"]) || array_key_exists("compteur", $context) ? $context["compteur"] : (function () { throw new Twig_Error_Runtime('Variable "compteur" does not exist.', 33, $this->source); })()) + 1);
                        // line 34
                        echo "                ";
                        $context["condition"] = false;
                        // line 35
                        echo "            ";
                    }
                    // line 36
                    echo "        ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tarifvol'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 37
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['classe'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "</tr>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "/vol/_card_vol.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 38,  136 => 37,  129 => 36,  126 => 35,  123 => 34,  121 => 33,  117 => 31,  111 => 30,  100 => 26,  94 => 25,  90 => 23,  87 => 22,  83 => 21,  79 => 19,  76 => 18,  70 => 17,  67 => 16,  63 => 15,  57 => 12,  53 => 11,  47 => 8,  43 => 7,  37 => 4,  33 => 3,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <p>Départ : {{ vol.Depart|date('Y-m-d H:i:s') }}</p>
        <p>Arrivée : {{ vol.Arrivee|date('Y-m-d H:i:s') }}</p>
    </td>
    <td>
        <p>Avion : {{ vol.Avion.Modele }}</p>
        <p>Places Restantes : {{ vol.getPlacesRestantes() }}</p>
    </td>
    <td>
        <p>Durée : {{ vol.Trajet.Duree|date('H:i:s') }}</p> 
        <p>Distance : {{ vol.Trajet.Distance }} KM</p>
    </td>

    {% for classe in classes %}
        {% set condition = true %}
        {% for tarifvol in vol.tarifVols if condition %}
            {% if tarifvol.Tarif.Classe.id == classe.id %}
                <td>
                    <table>
                        {% for tarifvol in vol.tarifVols %}
                            {% if tarifvol.Tarif.Classe.id == classe.id %}
                                <tr>
                                    <td>
                                        <input style=\"position:relative;opacity:1;pointer-events:auto\" name=\"choix\" value=\"{{tarifvol.id}}\" type=\"radio\" id=\"{{compteur}}\"/>
                                        <label for=\"{{compteur}}\">{{ tarifvol.Tarif.Tarif }} : {{ tarifvol.Prix }} €</label>
                                    </td>
                                </tr>
                            {% endif %}
                        {% endfor %}
                    </table>             
                </td>
                {% set compteur = compteur + 1 %}
                {% set condition = false %}
            {% endif %}
        {% endfor %}
    {% endfor %}
</tr>", "/vol/_card_vol.html.twig", "C:\\symfony\\AirAtlantique\\templates\\vol\\_card_vol.html.twig");
    }
}
