<?php

/* vol/vol.html.twig */
class __TwigTemplate_274f61429c327fa9ec074bf7a756500f559b8e4fa29935e287b44de058b13eca extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "vol/vol.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/vol.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/vol.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"center\">
    ";
        // line 5
        if (twig_test_empty((isset($context["trajet"]) || array_key_exists("trajet", $context) ? $context["trajet"] : (function () { throw new Twig_Error_Runtime('Variable "trajet" does not exist.', 5, $this->source); })()))) {
            // line 6
            echo "        <h3>Pas de trajet correspondant</h3>
    ";
        } else {
            // line 8
            echo "        <h4>Correspondances ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["depart"]) || array_key_exists("depart", $context) ? $context["depart"] : (function () { throw new Twig_Error_Runtime('Variable "depart" does not exist.', 8, $this->source); })()), "getNom", [], "method"), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["arrivee"]) || array_key_exists("arrivee", $context) ? $context["arrivee"] : (function () { throw new Twig_Error_Runtime('Variable "arrivee" does not exist.', 8, $this->source); })()), "getNom", [], "method"), "html", null, true);
            echo "</h4>
        <form action=\"";
            // line 9
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("reservation");
            echo "\" method=\"post\">
            <table>
                <tr>
                    <th>
                        Horaire
                    </th>
                    <th>
                        Avion
                    </th>
                    <th>
                        Détails
                    </th>

                    ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new Twig_Error_Runtime('Variable "classes" does not exist.', 22, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["classe"]) {
                // line 23
                echo "                        <th>
                            ";
                // line 24
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classe"], "Classe", []), "html", null, true);
                echo "
                        </th>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['classe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "                </tr>
                ";
            // line 28
            $context["compteur"] = 0;
            // line 29
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["vols"]) || array_key_exists("vols", $context) ? $context["vols"] : (function () { throw new Twig_Error_Runtime('Variable "vols" does not exist.', 29, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["vol"]) {
                // line 30
                echo "                    
                    ";
                // line 31
                $this->loadTemplate("/vol/_card_vol.html.twig", "vol/vol.html.twig", 31)->display($context);
                // line 32
                echo "
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['vol'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "            </table>
            ";
            // line 35
            if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 35, $this->source); })()), "user", [])) {
                // line 36
                echo "                <div class=\"row\">
                    <div class=\"input-field col s12 center\">
                        <button class=\"btn waves-effect waves-light red lighten-1\" type=\"submit\" name=\"action\">Réserver
                        <i class=\"material-icons right\">flight</i>
                        </button>
                    </div>
                </div>
            ";
            }
            // line 44
            echo "        </form>
    ";
        }
        // line 46
        echo "        
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "vol/vol.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 46,  159 => 44,  149 => 36,  147 => 35,  144 => 34,  129 => 32,  127 => 31,  124 => 30,  106 => 29,  104 => 28,  101 => 27,  92 => 24,  89 => 23,  85 => 22,  69 => 9,  62 => 8,  58 => 6,  56 => 5,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"center\">
    {% if trajet is empty %}
        <h3>Pas de trajet correspondant</h3>
    {% else %}
        <h4>Correspondances {{ depart.getNom() }} - {{ arrivee.getNom() }}</h4>
        <form action=\"{{path(\"reservation\")}}\" method=\"post\">
            <table>
                <tr>
                    <th>
                        Horaire
                    </th>
                    <th>
                        Avion
                    </th>
                    <th>
                        Détails
                    </th>

                    {% for classe in classes %}
                        <th>
                            {{ classe.Classe }}
                        </th>
                    {% endfor %}
                </tr>
                {% set compteur = 0 %}
                {% for vol in vols %}
                    
                    {% include '/vol/_card_vol.html.twig' %}

                {% endfor %}
            </table>
            {% if app.user %}
                <div class=\"row\">
                    <div class=\"input-field col s12 center\">
                        <button class=\"btn waves-effect waves-light red lighten-1\" type=\"submit\" name=\"action\">Réserver
                        <i class=\"material-icons right\">flight</i>
                        </button>
                    </div>
                </div>
            {% endif %}
        </form>
    {% endif %}
        
    </div>
{% endblock %}
", "vol/vol.html.twig", "C:\\symfony\\AirAtlantique\\templates\\vol\\vol.html.twig");
    }
}
