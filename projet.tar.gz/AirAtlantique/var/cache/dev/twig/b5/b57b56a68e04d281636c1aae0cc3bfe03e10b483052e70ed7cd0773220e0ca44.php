<?php

/* vol/verif.html.twig */
class __TwigTemplate_11240414df0a7d8e6f191731d62e111a6b81ef7c711cdb471271e81e53d94d84 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "vol/verif.html.twig", 1);
        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/verif.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/verif.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Hello HomeController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
    <div class=\"row\">
        <div class=\"col s12\">
            <div class=\"card\">
                <div class=\"card-content\">
                    <span class=\"card-title center\">Voulez-vous supprimer ce billet ?</span>
                    <p>";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 12, $this->source); })()), "Vol", []), "Vol", []), "Trajet", []), "Depart", []), "Nom", []), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 12, $this->source); })()), "Vol", []), "Vol", []), "Trajet", []), "Arrivee", []), "Nom", []), "html", null, true);
        echo "</p>
                    <p>Départ à ";
        // line 13
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 13, $this->source); })()), "Vol", []), "Vol", []), "Depart", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
                    <p>Arrivée à ";
        // line 14
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 14, $this->source); })()), "Vol", []), "Vol", []), "Arrivee", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
                    <p>";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 15, $this->source); })()), "Vol", []), "Tarif", []), "Classe", []), "Classe", []), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 15, $this->source); })()), "Vol", []), "Tarif", []), "Tarif", []), "html", null, true);
        echo " : ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 15, $this->source); })()), "Vol", []), "Prix", []), "html", null, true);
        echo "€</p>
                    <p> billet acheté le ";
        // line 16
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 16, $this->source); })()), "Date", []), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
                </div>
                <div class=\"card-action\">

                    <form action=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete");
        echo "\" method=\"post\">
                        <input type=\"hidden\" name=\"id\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["billet"]) || array_key_exists("billet", $context) ? $context["billet"] : (function () { throw new Twig_Error_Runtime('Variable "billet" does not exist.', 21, $this->source); })()), "Id", []), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn waves-effect waves-light red lighten-1\">OUI</button>
                        <a class=\"btn waves-effect waves-light red lighten-1\" href=\"";
        // line 23
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("our-flight");
        echo "\">NON</a>
                    </form>

                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "vol/verif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 23,  113 => 21,  109 => 20,  102 => 16,  94 => 15,  90 => 14,  86 => 13,  80 => 12,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Hello HomeController!{% endblock %}

{% block body %}

    <div class=\"row\">
        <div class=\"col s12\">
            <div class=\"card\">
                <div class=\"card-content\">
                    <span class=\"card-title center\">Voulez-vous supprimer ce billet ?</span>
                    <p>{{billet.Vol.Vol.Trajet.Depart.Nom}} - {{billet.Vol.Vol.Trajet.Arrivee.Nom}}</p>
                    <p>Départ à {{ billet.Vol.Vol.Depart|date('Y-m-d H:i:s') }}</p>
                    <p>Arrivée à {{ billet.Vol.Vol.Arrivee|date('Y-m-d H:i:s') }}</p>
                    <p>{{billet.Vol.Tarif.Classe.Classe}} {{billet.Vol.Tarif.Tarif}} : {{billet.Vol.Prix}}€</p>
                    <p> billet acheté le {{ billet.Date|date('Y-m-d H:i:s') }}</p>
                </div>
                <div class=\"card-action\">

                    <form action=\"{{path(\"delete\")}}\" method=\"post\">
                        <input type=\"hidden\" name=\"id\" value=\"{{billet.Id}}\"/>
                        <button type=\"submit\" class=\"btn waves-effect waves-light red lighten-1\">OUI</button>
                        <a class=\"btn waves-effect waves-light red lighten-1\" href=\"{{path(\"our-flight\")}}\">NON</a>
                    </form>

                </div>
            </div>
        </div>
    </div>

{% endblock %}
", "vol/verif.html.twig", "C:\\symfony\\AirAtlantique\\templates\\vol\\verif.html.twig");
    }
}
