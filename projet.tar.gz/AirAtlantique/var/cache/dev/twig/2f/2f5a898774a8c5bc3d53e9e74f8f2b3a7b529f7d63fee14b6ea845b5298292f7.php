<?php

/* @WebProfiler/Icon/twig.svg */
class __TwigTemplate_d8ede58d70f64148042357d9f521f4d41618b45e04d1caceca88e891c83b13d8 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/twig.svg"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/twig.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"m8.932327,22.491763c0.015209,-6.448229 -0.971579,-11.295129 -5.994828,-11.618392c4.689807,-0.35251 7.112354,2.633007 9.29714,6.906552c-0.030468,-11.426311 -2.352459,-16.227324 -7.433672,-16.482536c7.433365,0.069108 10.027703,5.898928 11.508208,14.292954c1.170879,-2.282766 3.560547,-5.553431 5.347074,-1.361535c-1.59464,-2.040144 -3.607126,-1.61697 -3.978662,8.261983l-8.744646,0.000107z\"/>
</svg>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/twig.svg";
    }

    public function getDebugInfo()
    {
        return array (  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"m8.932327,22.491763c0.015209,-6.448229 -0.971579,-11.295129 -5.994828,-11.618392c4.689807,-0.35251 7.112354,2.633007 9.29714,6.906552c-0.030468,-11.426311 -2.352459,-16.227324 -7.433672,-16.482536c7.433365,0.069108 10.027703,5.898928 11.508208,14.292954c1.170879,-2.282766 3.560547,-5.553431 5.347074,-1.361535c-1.59464,-2.040144 -3.607126,-1.61697 -3.978662,8.261983l-8.744646,0.000107z\"/>
</svg>
", "@WebProfiler/Icon/twig.svg", "C:\\symfony\\AirAtlantique\\vendor\\symfony\\web-profiler-bundle\\Resources\\views\\Icon\\twig.svg");
    }
}
