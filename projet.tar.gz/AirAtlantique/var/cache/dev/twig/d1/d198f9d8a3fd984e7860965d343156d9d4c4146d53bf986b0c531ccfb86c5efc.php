<?php

/* vol/our_flight.html.twig */
class __TwigTemplate_7b78f094ede3548e39c83e606890a96cb3d6f27ab18376cb2242aa3b93191e0b extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "vol/our_flight.html.twig", 1);
        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/our_flight.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "vol/our_flight.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Hello HomeController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div>
    <h1>Vos Vols<i class=\"material-icons medium right\">flight</i></h1>
    
    ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["billets"]) || array_key_exists("billets", $context) ? $context["billets"] : (function () { throw new Twig_Error_Runtime('Variable "billets" does not exist.', 9, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["billet"]) {
            // line 10
            echo "        <div class=\"row\">
            <div class=\"col s12\">
                <div class=\"card\">
                    <div class=\"card-content\">
                        <span class=\"card-title center\">";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Vol", []), "Trajet", []), "Depart", []), "Nom", []), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Vol", []), "Trajet", []), "Arrivee", []), "Nom", []), "html", null, true);
            echo "</span>
                        <p>Départ à ";
            // line 15
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Vol", []), "Depart", []), "Y-m-d H:i:s"), "html", null, true);
            echo "</p>
                        <p>Arrivée à ";
            // line 16
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Vol", []), "Arrivee", []), "Y-m-d H:i:s"), "html", null, true);
            echo "</p>
                        <p>";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Tarif", []), "Classe", []), "Classe", []), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Tarif", []), "Tarif", []), "html", null, true);
            echo " : ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["billet"], "Vol", []), "Prix", []), "html", null, true);
            echo "€</p>
                        <p> billet acheté le ";
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["billet"], "Date", []), "Y-m-d H:i:s"), "html", null, true);
            echo "</p>
                    </div>
                    <div class=\"card-action\">

                        <form action=\"";
            // line 22
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("verif");
            echo "\" method=\"post\">
                            <input type=\"hidden\" name=\"id\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["billet"], "Id", []), "html", null, true);
            echo "\"/>
                            <button type=\"submit\" class=\"btn waves-effect waves-light red lighten-1\">Supprimer</button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['billet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "vol/our_flight.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 32,  120 => 23,  116 => 22,  109 => 18,  101 => 17,  97 => 16,  93 => 15,  87 => 14,  81 => 10,  77 => 9,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Hello HomeController!{% endblock %}

{% block body %}
<div>
    <h1>Vos Vols<i class=\"material-icons medium right\">flight</i></h1>
    
    {% for billet in billets %}
        <div class=\"row\">
            <div class=\"col s12\">
                <div class=\"card\">
                    <div class=\"card-content\">
                        <span class=\"card-title center\">{{billet.Vol.Vol.Trajet.Depart.Nom}} - {{billet.Vol.Vol.Trajet.Arrivee.Nom}}</span>
                        <p>Départ à {{ billet.Vol.Vol.Depart|date('Y-m-d H:i:s') }}</p>
                        <p>Arrivée à {{ billet.Vol.Vol.Arrivee|date('Y-m-d H:i:s') }}</p>
                        <p>{{billet.Vol.Tarif.Classe.Classe}} {{billet.Vol.Tarif.Tarif}} : {{billet.Vol.Prix}}€</p>
                        <p> billet acheté le {{ billet.Date|date('Y-m-d H:i:s') }}</p>
                    </div>
                    <div class=\"card-action\">

                        <form action=\"{{path(\"verif\")}}\" method=\"post\">
                            <input type=\"hidden\" name=\"id\" value=\"{{billet.Id}}\"/>
                            <button type=\"submit\" class=\"btn waves-effect waves-light red lighten-1\">Supprimer</button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    {% endfor %}

</div>

{% endblock %}
", "vol/our_flight.html.twig", "C:\\symfony\\AirAtlantique\\templates\\vol\\our_flight.html.twig");
    }
}
